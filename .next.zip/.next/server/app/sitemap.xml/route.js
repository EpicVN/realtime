var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__18dbbb52._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_sitemap_xml_route_actions_12658ace.js")
R.m(8922)
module.exports=R.m(8922).exports
