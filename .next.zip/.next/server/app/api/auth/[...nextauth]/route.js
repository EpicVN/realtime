var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[root-of-the-server]__2c39dc35._.js")
R.c("server/chunks/node_modules_bcryptjs_index_42ebb250.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_next_bf398cb2._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_[___nextauth]_route_actions_1c865db8.js")
R.m(59061)
module.exports=R.m(59061).exports
