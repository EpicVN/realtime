var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/users/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__6e944403._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_bcryptjs_index_42ebb250.js")
R.c("server/chunks/_next-internal_server_app_api_users_[id]_route_actions_e7269cbb.js")
R.m(10409)
module.exports=R.m(10409).exports
