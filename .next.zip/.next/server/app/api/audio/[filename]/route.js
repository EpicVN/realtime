var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/audio/[filename]/route.js")
R.c("server/chunks/[root-of-the-server]__20902f24._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_audio_[filename]_route_actions_c9e6a35a.js")
R.m(20288)
module.exports=R.m(20288).exports
