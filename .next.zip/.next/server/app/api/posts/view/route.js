var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/posts/view/route.js")
R.c("server/chunks/[root-of-the-server]__eb128bb0._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_posts_view_route_actions_7c790f07.js")
R.m(34741)
module.exports=R.m(34741).exports
