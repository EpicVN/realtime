var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/posts/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__cc8e3aef._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_posts_[id]_route_actions_ba6d08ac.js")
R.m(71144)
module.exports=R.m(71144).exports
