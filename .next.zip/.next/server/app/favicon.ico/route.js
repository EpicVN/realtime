var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__5abad3c9._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_favicon_ico_route_actions_353150a5.js")
R.m(17951)
module.exports=R.m(17951).exports
