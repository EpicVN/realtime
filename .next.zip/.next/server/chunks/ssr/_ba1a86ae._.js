module.exports=[37936,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"registerServerReference",{enumerable:!0,get:function(){return d.registerServerReference}});let d=a.r(11857)},13095,(a,b,c)=>{"use strict";function d(a){for(let b=0;b<a.length;b++){let c=a[b];if("function"!=typeof c)throw Object.defineProperty(Error(`A "use server" file can only export async functions, found ${typeof c}.
Read more: https://nextjs.org/docs/messages/invalid-use-server-value`),"__NEXT_ERROR_CODE",{value:"E352",enumerable:!1,configurable:!0})}}Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"ensureServerEntryExports",{enumerable:!0,get:function(){return d}})},82808,a=>{"use strict";var b=a.i(37936),c=a.i(31191);async function d(a,b){let d=b.get("name"),f=b.get("email"),g=b.get("phone"),h=b.get("interest"),i=b.get("message");if(!d||!f)return{success:!1,message:"Vui lòng điền tên và email!"};try{let a=await c.prisma.contact.create({data:{name:d,email:f,phone:g,interest:h,message:i||"Khách không để lại lời nhắn",status:"PENDING"}});return await e(a),{success:!0,message:"Gửi yêu cầu thành công! Chúng tôi sẽ liên hệ sớm."}}catch(a){return console.error("Lỗi gửi form:",a),{success:!1,message:"Lỗi hệ thống, vui lòng thử lại sau."}}}async function e(a){let b=process.env.TELEGRAM_BOT_TOKEN,c=process.env.TELEGRAM_CHAT_ID;if(!b||!c)return;let d=`
🔥 **NEW ORDER - REALTIME WEBSITE**
-------------------------
👤 **Name:** ${a.name}
📧 **Email:** ${a.email}
📞 **Phone:** ${a.phone||"N/A"}
👥 **User quy m\xf4:** ${a.interest||"N/A"}
📝 **Note:** ${a.message}
-------------------------
⏰ ${new Date().toLocaleString("vi-VN")}
  `;try{await fetch(`https://api.telegram.org/bot${b}/sendMessage`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({chat_id:c,text:d,parse_mode:"Markdown"})})}catch(a){console.error("Telegram Error:",a)}}(0,a.i(13095).ensureServerEntryExports)([d]),(0,b.registerServerReference)(d,"60203f8c92ebc44d05e11d5cb30a8cf649029b998b",null),a.s(["submitContactForm",()=>d])},55525,a=>{"use strict";var b=a.i(82808);a.s([],91853),a.i(91853),a.s(["60203f8c92ebc44d05e11d5cb30a8cf649029b998b",()=>b.submitContactForm],55525)}];

//# sourceMappingURL=_ba1a86ae._.js.map