module.exports=[49916,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_%28site%29_partners_page_actions_3ff06f91.js.map