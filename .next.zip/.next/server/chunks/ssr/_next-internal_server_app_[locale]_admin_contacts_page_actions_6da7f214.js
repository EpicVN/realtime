module.exports=[68412,a=>{"use strict";var b=a.i(50363);a.s([],73444),a.i(73444),a.s(["0067a73687ee1428d72b98858713d9f12f91e60fc6",()=>b.$$RSC_SERVER_ACTION_0],68412)}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_admin_contacts_page_actions_6da7f214.js.map