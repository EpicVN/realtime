module.exports=[81956,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_%28site%29_posts_%5Bslug%5D_page_actions_0a54ac43.js.map