module.exports=[96550,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_%28site%29_thank-you_page_actions_0b25c420.js.map