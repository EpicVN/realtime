module.exports=[79516,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_%28site%29_posts_page_actions_d4296779.js.map