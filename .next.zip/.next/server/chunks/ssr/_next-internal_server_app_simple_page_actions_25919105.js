module.exports=[80381,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_simple_page_actions_25919105.js.map