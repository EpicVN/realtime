module.exports=[22713,a=>{"use strict";var b=a.i(50363);a.s([],38662),a.i(38662),a.s(["0067a73687ee1428d72b98858713d9f12f91e60fc6",()=>b.$$RSC_SERVER_ACTION_0],22713)}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_admin_posts_edit_%5Bid%5D_page_actions_061c2d94.js.map