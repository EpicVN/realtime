module.exports=[56493,a=>{"use strict";var b=a.i(50363);a.s([],66179),a.i(66179),a.s(["0067a73687ee1428d72b98858713d9f12f91e60fc6",()=>b.$$RSC_SERVER_ACTION_0],56493)}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_admin_posts_create_page_actions_41b09548.js.map