module.exports=[17761,a=>{"use strict";var b=a.i(50363);a.s([],94980),a.i(94980),a.s(["0067a73687ee1428d72b98858713d9f12f91e60fc6",()=>b.$$RSC_SERVER_ACTION_0],17761)}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_admin_page_actions_e2f38890.js.map